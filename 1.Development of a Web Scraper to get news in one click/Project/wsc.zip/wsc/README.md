# wsc

python -m ensurepip
python -m venv venv
powershell -ExecutionPolicy Bypass
venv\Scripts\activate
pip install -r requirements.txt



